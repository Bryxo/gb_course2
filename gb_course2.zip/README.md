# gb_2course
Practice

My first trying in frontend development=)
Its wonderful
